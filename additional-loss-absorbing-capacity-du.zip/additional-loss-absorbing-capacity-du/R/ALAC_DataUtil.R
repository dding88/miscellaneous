
# =============== AWS S3 fucntions utilizing MDU package =============== #



#' getting all metadata for the model
#' @param model.id : model ID
#' @param model.version : model version
#' @return meta data for all model runs
#' @import mdu
#' @import pool
#' @import dplyr
#' @import purrr
#' @export
get_metadata_model <- function(model.id, model.version) {
  get.meta.data()%>%
    filter(model_id == model.id & model_version == model.version)
}

#' getting all metadata for the model regarless of version
#' @param model.id : model ID
#' @return meta data for all model runs
#' @export
get_metadata_model_all_version <- function(model.id) {
  get.meta.data()%>%
    filter(model_id == model.id)
}


#' getting all metadata for latest run based for specific year and entity, updated
#' @param model.id : model ID
#' @param model.version : model version
#' @param year : year the alac was calculated
#' @param entity.name : entity name
#' @return meta data for latest model runs
#' @export
get_metadata_latest_run_year_entity <- function(model.id, model.version, year, entity.name) {
 get_metadata_model(model.id, model.version)%>%
    filter(analysis_year == year &  entity_name == entity.name)%>%
    filter(created == max(created))%>%
    distinct()
}


#' getting all metadata for latest run based for specific entity, updated
#' @param model.id : model ID
#' @param model.version : model version
#' @param entity.name : entity name
#' @return meta data for latest model runs
#' @export
get_metadata_latest_run_based_on_entity <- function(model.id, model.version, entity.name) {
  get_metadata_model(model.id, model.version) %>%
    filter(entity_name == entity.name) %>%
    filter(created == max(created))%>%
    distinct()
}

#' getting all metadata for all runs for a specific year and entity, updated
#' @param model.id : model ID
#' @param model.version : model version
#' @param year : run year
#' @param entity.name : entity name
#' @return meta data for all model runs
#' @export
get_metadata_all_run_year_entity <- function(model.id, model.version, year, entity.name) {
  get_metadata_model(model.id, model.version)%>%
    filter(analysis_year == year & entity_name == entity.name)%>%
    distinct()
}

#' getting all metadata for all runs for a specific entity, updated 10072021
#' @param model.id : model ID
#' @param model.version : model version
#' @param entity.name : entity name
#' @return meta data for all model runs
#' @export
get_metadata_all_run_entity <- function(model.id, model.version, entity.name) {
  get_metadata_model(model.id, model.version) %>%
    filter(entity_name == entity.name)%>%
    distinct()
}

#' getting all keys for all runs for a specific entity, updated 10072021
#' @param model.id : model ID
#' @param model.version : model version
#' @param entity.name : entity name
#' @return meta data for all model runs
#' @export
get_keys_entity <- function(model.id, model.version, entity.name) {
  get_metadata_model(model.id, model.version) %>%
    filter(entity_name == entity.name)%>%
    select(key) %>%
    pull()
}





#' getting  model data for latest run for a specific entity,updated
#' @param model.id : model ID
#' @param model.version : model version
#' @param entity.name : entity name
#' @return model data for latest model runs in a list
#' @export
get_model_data_latest_run_based_on_entity <- function(model.id, model.version, entity.name) {
  one.ALAC.record <- get_metadata_latest_run_based_on_entity(model.id, model.version, entity.name)
  model.data <- one.ALAC.record$key%>%
    get.model.data()
  return(model.data)
}



source("pipeline/utils.R")

package_deploy("pipeline", Sys.getenv("MINICRANDIR", "unlikely.directory.name"))

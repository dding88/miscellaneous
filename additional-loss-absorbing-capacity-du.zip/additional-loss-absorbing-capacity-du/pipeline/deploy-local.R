source("pipeline/utils.R")

repo_dir = paste0("/sandbox_repo/", version$major, ".", version$minor)

package_deploy("pipeline", repo_dir)

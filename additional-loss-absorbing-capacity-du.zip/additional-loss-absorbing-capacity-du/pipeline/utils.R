library(assertthat)
library(purrr)
library(magrittr)
library(devtools)
library(testthat)
library(stringr)

get_name_pkg <- function(dir) {
  list.files(dir, pattern = "\\.tar\\.gz$") %>%
    gsub(pattern = "\\_.*", replacement = "", x = .) %>%
    trimws()
}

gen_docs <- function(step_name) {
  print(paste(" --", step_name, ": Generating roxygen documentation"))
  devtools::document()
}

clean_prior_builds <- function(step_name, dir) {
  print(paste(" --", step_name, ": Cleaning prior builds"))
  list.files(dir, pattern = "\\.tar\\.gz$", full.names = TRUE) %>%
    map(file.remove)
}

build_pkg <- function(step_name, dir) {
  print(paste(" --", step_name, ": Building package"))
  devtools::build(pkg = ".", path = dir)
}

check_pkg <- function(step_name, dir) {
  print(paste(" --", step_name, ": Checking build package without running tests"))
  pkg_tarball <- list.files(dir, pattern = "\\.tar\\.gz$")
  devtools::check_built(file.path(dir, pkg_tarball),
                        args = c("--no-examples", "--no-tests"),
                        error_on = "error")
}

remove_installed <- function(step_name, dir) {
  print(paste(" --", step_name, ": Removing prior installation"))
  pkg_name <- get_name_pkg(dir)
  if (pkg_name %in% row.names(installed.packages()))
    try(remove.packages(pkg_name))

  invisible(pkg_name)
}

install_pkg <- function(step_name, dir, from_repo = TRUE) {
  msg <-  paste(" --", step_name, ": Installing package to library")

  if (from_repo)
    msg <- paste(msg, "from repository")
  else
    msg <- paste(msg, "from locally built tarball")

  print(msg)

  if (from_repo) {
    pkg_name <- get_name_pkg(dir)
    detach(paste0("package:", pkg_name), unload = TRUE, character.only = TRUE)
    Sys.setenv(R_INSTALL_STAGED = FALSE)
    install.packages(pkg_name, type = "source",
                     INSTALL_opts = "--install-tests")
  } else {
    pkg_tarball <- list.files(dir, pattern = "\\.tar\\.gz$")
    install.packages(file.path(dir, pkg_tarball), type = "source", repos = NULL,
                     INSTALL_opts = "--install-tests")
  }
}

test_pkg <- function(step_name, dir) {
  print(paste(" --", step_name, ": Running package tests"))
  testthat::test_package(get_name_pkg(dir), reporter = "tap")
}

remove_from_minicran <- function(step_name, pkg_name, dir) {
  print(paste(" --", step_name, ": Removing package from Mini CRAN"))

  assert_that(is.character(pkg_name) && length(pkg_name) == 1 && str_length(pkg_name) > 0,
              msg = "Invalid or empty package name")
  valid_chars <- str_match(pkg_name, "[\\.0-9a-zA-Z]+")
  assert_that(!is.na(valid_chars) && str_length(valid_chars) == str_length(pkg_name),
              msg = "Invalid package name")

  paste0(pkg_name, ".*tar.gz") %>%
    list.files(paste(dir, "src", "contrib", sep = "/"), ., full.names = TRUE) %>%
    map(file.remove)
  miniCRAN::updateRepoIndex(dir)
}

add_to_minicran <- function(step_name, build_dir, repo_dir) {
  print(paste(" --", step_name, ": Adding package to Mini CRAN"))
  miniCRAN::addLocalPackage(pkgs = get_name_pkg(build_dir), pkgPath = build_dir,
                            path = repo_dir, type = "source")
}

package_check <- function(build_dir) {
  assertthat::assert_that(dir.exists(build_dir),
                          msg = paste("Build directory", build_dir, "not found"))

  gen_docs("Check Step 1")

  clean_prior_builds("Check Step 2", build_dir)

  build_pkg("Check Step 3", build_dir)

  check_pkg("Check Step 4", build_dir)
}

package_test <- function(build_dir) {
  assertthat::assert_that(dir.exists(build_dir),
                          msg = paste("Build directory", build_dir, "not found"))

  clean_prior_builds("Test Step 1", build_dir)

  build_pkg("Test Step 2", build_dir)

  remove_installed("Test Step 3", build_dir)

  install_pkg("Test Step 4", build_dir, from_repo = FALSE)

  test_pkg("Test Step 5", build_dir)

  remove_installed("Test Step 6", build_dir)
}

package_deploy <- function(build_dir, repo_dir) {
  assertthat::assert_that(dir.exists(build_dir),
                          msg = paste("Build directory", build_dir, "not found"))
  assertthat::assert_that(dir.exists(repo_dir),
                          msg = paste("Repository directory", repo_dir, "not found"))

  gen_docs("Deploy Step 1")

  clean_prior_builds("Deploy Step 2", build_dir)

  build_pkg("Deploy Step 3", build_dir)

  remove_from_minicran("Deploy Step 4", get_name_pkg(build_dir), repo_dir)

  add_to_minicran("Deploy Step 5", build_dir, repo_dir)

  install_pkg("Deploy Step 6", build_dir, from_repo = TRUE)
}

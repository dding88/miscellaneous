library(purrr)

# setup({
Sys.setenv(R_CONFIG_ACTIVE = "production")
# })

test_that("test mdu get meta data func", {
  print("test1")
  expect_equal(is_empty(get_metadata_model(1118, 1)), FALSE)
})

test_that("test mdu get meta data func regardless of version", {
  print("Aegon Bank")
  expect_equal(is_empty(get_metadata_model_all_version(1118)), FALSE)
})

# test_that("test mdu get meta data for last run", {
#   print("test3")
#   expect_equal(is_empty(get_metadata_latest_run(1118, 1, "derek ding", "ABC")), FALSE)
# })

# test_that("test mdu get meta data for last run analyst", {
#   print("test4")
#   expect_equal(is_empty(get_metadata_latest_run_based_on_analyst(1118, 1, "derek ding")), FALSE)
# })

# test_that("test mdu get meta data for last run entity", {
#   print("test5")
#   expect_equal(is_empty(get_metadata_latest_run_based_on_analyst(1118, 1, "ABC")), FALSE)
# })

# test_that("test mdu get meta data for all run", {
#   print("test6")
#   expect_equal(is_empty(get_metadata_all_run(1118, 1, "derek ding", "ABC")), FALSE)
# })



# test_that("test mdu get model data for last run analyst", {
#   print("test6")
#   expect_equal(is_empty(get_model_data_latest_run_based_on_analyst(1118, 1, "derek ding")), FALSE)
# })

test_that("test mdu get model data for last run entity", {
  print("test3")
  expect_equal(is_empty(get_model_data_latest_run_based_on_entity(1118, 1, "Aegon Bank")), FALSE)
})

# test_that("test mdu get model data for one key", {
#   print("test4")
#   expect_equal(is_empty(get_model_data_one_key("Dev/model-data/1118/1/2021-08-20-21:00:15.1794.json")), FALSE)
# })

#new test cases for assigning spid entity name AND analysis_year year of run_date
test_that("test meta data for last record year and  entity", {
  print("test4")
  expect_equal(is_empty(get_metadata_latest_run_year_entity(1118,1,"2021","Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name
test_that("test meta data for last record of spid=entity", {
  print("test5")
  expect_equal(is_empty(get_metadata_latest_run_based_on_entity(1118,1,"Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name
test_that("test meta data for last record of spid=entity", {
  print("test6")
  expect_equal(is_empty(get_metadata_latest_run_based_on_entity(1118,1,"Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name AND analysis_year year of run_date
test_that("test meta data for all recoreds based on year and  entity", {
  print("test7")
  expect_equal(is_empty(get_metadata_all_run_year_entity(1118,1,"2021","Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name  
test_that("test meta data for all recoreds based on entity", {
  print("test8")
  expect_equal(is_empty(get_metadata_all_run_entity(1118,1,"Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name  
test_that("test get keys for all recoreds based on entity", {
  print("test9")
  expect_equal(is_empty(get_keys_entity(1118,1,"Aegon Bank")), FALSE)
})

#new test cases for assigning spid entity name
test_that("test model data for last record of spid=entity", {
  print("test10")
  expect_equal(is_empty(get_model_data_latest_run_based_on_entity(1118,1,"Aegon Bank")), FALSE)
})


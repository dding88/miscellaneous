spdeployr::package_deploy("pipeline", Sys.getenv("MINICRANDIR", "unlikely.directory.name"))

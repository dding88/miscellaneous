repo_dir = paste0("/sandbox_repo/", version$major, ".", version$minor)

spdeployr::package_deploy("pipeline", repo_dir)

spdeployr::package_check("pipeline")
